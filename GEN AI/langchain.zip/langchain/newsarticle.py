import nest_asyncio
import streamlit as st
from duckduckgo_search import DDGS
from phi.tools.newspaper4k import Newspaper4k
from langchain.chat_models import ChatOpenAI
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Get OpenAI API key from environment variables
api_key = os.getenv("OPEN_API_KEY")
chat = ChatOpenAI(openai_api_key=api_key, temperature=0.5)

# Apply async behavior
nest_asyncio.apply()

# Set up Streamlit page configuration
st.set_page_config(page_title="News Article Summarizer", page_icon=":newspaper:")
st.title("News Article Summarizer with OpenAI")
st.markdown("##### :newspaper: Powered by OpenAI's API")

def main() -> None:
    """Main function for the Streamlit app."""
    # Input for article topic
    article_topic = st.text_input(":spiral_calendar_pad: Enter a topic", value="AI and its impact on society")
    search_button = st.button("Get News Summary")

    if search_button:
        news_results = []
        with st.spinner("Searching for news articles..."):
            ddgs = DDGS()
            newspaper_tools = Newspaper4k()
            results = ddgs.news(keywords=article_topic, max_results=5)  # Get a limited number of articles
            for r in results:
                if "url" in r:
                    article_data = newspaper_tools.get_article_data(r["url"])
                    if article_data and "text" in article_data:
                        r["text"] = article_data["text"]
                        news_results.append(r)

        if news_results:
            news_summary = ""
            with st.spinner("Summarizing news articles..."):
                for news_result in news_results:
                    news_summary += f"### {news_result['title']}\n\n"
                    news_summary += f"- Date: {news_result['date']}\n\n"
                    news_summary += f"- URL: {news_result['url']}\n\n"
                    news_summary += f"#### Content\n\n{news_result['text']}\n\n"

                    # Generate a summary using the ChatOpenAI model
                    summary_response = chat.invoke([{"role": "user", "content": f"Please summarize the following article:\n\n{news_result['text']}"}])
                    summary = summary_response.content.strip()  # Access content directly

                    news_summary += "#### Summary\n\n"
                    news_summary += summary + "\n\n---\n\n"

                # Display all summaries
                st.markdown(news_summary)
        else:
            st.write("No news articles found for this topic.")

        # Generate a title for the article
        title_response = chat.invoke([{"role": "user", "content": f"Generate a catchy title for an article about: {article_topic}."}])
        article_title = title_response.content.strip()  # Access content directly
        st.write(f"### Suggested Article Title: **{article_title}**")

    st.sidebar.markdown("---")
    if st.sidebar.button("Restart"):
        st.rerun()

# Run the main function
if __name__ == "__main__":
    main()
