from langchain_community.chat_models import ChatOpenAI 
from langchain.prompts.chat import ChatPromptTemplate
from langchain.schema import BaseOutputParser
from langchain.chains import LLMChain 
import os
import streamlit as st
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
api_key = os.getenv("OPEN_API_KEY")

# Initialize ChatOpenAI with your API key
chat = ChatOpenAI(openai_api_key=api_key, temperature=0.5)

# Custom output parser
class Commaseparatedoutput(BaseOutputParser):
    def parse(self, text: str):
        return text.strip().split(",")

# Set up Streamlit UI
st.set_page_config(page_title="Synonyms Generator")
st.header("📝 Synonyms Generator 🔄")

# Define the template for the chat prompt
template = "You are a helpful assistant. When the user provides any input, you should generate 5 words synonyms in a comma-separated list."
human_template = "{text}"

# Create the ChatPromptTemplate
chat_prompt = ChatPromptTemplate.from_messages([
    ("system", template),
    ("human", human_template)
])

# Create the LLM chain with the chat model and output parser
llm_chain = LLMChain(llm=chat, prompt=chat_prompt, output_parser=Commaseparatedoutput())

# Text input for user query
input_text = st.text_input("Enter a word or phrase:", "")

# Button to trigger the synonym generation
if st.button("Generate Synonyms"):
    # Perform the conversation with the chatbot
    if input_text:
        # Get the chatbot response using predict
        response = llm_chain.predict(text=input_text)

        # Display the synonyms
        st.write("Synonyms:", ", ".join(response))  # Adjusted to use response directly
    else:
        st.write("Please enter a word or phrase.")
