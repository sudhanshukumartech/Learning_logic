def fibonacci_series(n):
    # First two terms of the Fibonacci series
    a, b = 0, 1
    # Generate and print each term of the series
    for _ in range(n):
        print(a, end=" ")
        a, b = b, a + b

# Number of terms in the Fibonacci series
num_terms = 10
fibonacci_series(num_terms)
